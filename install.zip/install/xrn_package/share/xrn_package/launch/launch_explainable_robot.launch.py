#!/usr/bin/env python3
import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    reasoning = Node(
        package='xrn_package',
        executable='reasoning_node',
        name='reasoning_node',
        output='screen',
        emulate_tty=True,
        parameters=[{
            'safe_distance': 1.0,
            'edge_confidence_threshold': 3,
            'edge_front_threshold': 1.0,
            'tilt_edge_threshold': 0.2,
            'tilt_unstable_threshold': 0.25,
            'side_window': 40
        }],
    )

    navigator = Node(
        package='xrn_package',
        executable='autonomous_navigator',
        name='autonomous_navigator',
        output='screen',
        emulate_tty=True,
        parameters=[{
            'safe_distance': 0.6,
            'stop_distance': 0.22,
            'hysteresis': 0.12,
            'forward_speed': 0.08,
            'rotate_speed': 0.6,
            'control_hz': 15.0,
            'center_window': 8,
            'side_window': 40,
            'reverse_time': 1.0,
            'rotate_time': 2.0,
            'stuck_rotate_timeout': 5.0,
            # geofence bounds - tune to your world
            'geofence_min_x': -9.5,
            'geofence_max_x': 9.5,
            'geofence_min_y': -9.5,
            'geofence_max_y': 9.5,
            'geofence_margin': 0.6
        }],
    )

    explanation = Node(
        package='xrn_package',
        executable='explanation_node',
        name='explanation_node',
        output='screen',
        emulate_tty=True,
        parameters=[{
            'model_name': os.environ.get('XRN_HF_MODEL', 'deepseek-ai/DeepSeek-V3.2-Exp:novita'),
            'max_tokens': 150,
            'timeout_s': 15.0
        }]
    )

    return LaunchDescription([reasoning, navigator, explanation])
